import React from "react";

function MainListPage() {
  return <div>MainListPage</div>;
}

export default MainListPage;
