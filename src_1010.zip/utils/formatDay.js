export const formatDay = (date) => {
  const [year, month, day] = date;
  return `${year}년 ${month}월 ${day}일`;
};
